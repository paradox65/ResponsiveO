<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
 
jimport('joomla.form.formfield');
 
class JFormFieldModalexport extends JFormField
{
	protected $type = 'modalexport';

	public function getInput()
	{
		JHtml::_('behavior.modal', 'a.modal');
		
		return '<a href="" target="_blank" class="btn btn-info">Export</a>';
	}
}
