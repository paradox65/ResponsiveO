<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
 
jimport('joomla.form.formfield');
 
class JFormFieldRadiomenulevel extends JFormFieldRadio
{
	protected $type = 'radiomenulevel';

	public function getInput()
	{
		$checked0 = ($this->value == 'main_menu')? 'checked="checked"' : '';
		$checked1 = ($this->value == 'sub_menu')? 'checked="checked"' : '';
		$checked2 = ($this->value == 'footer_menu')? 'checked="checked"' : '';
		
		return '
		<fieldset id="'.$this->id.'" class="btn-group jmg-btn-level radio">
		<input type="radio" id="'.$this->id.'0" name="'.$this->name.'" value="main_menu" '.$checked0.' />			
		<label for="'.$this->id.'0" >Main Menu</label>
		<input type="radio" id="'.$this->id.'1" name="'.$this->name.'" value="sub_menu" '.$checked1.' />			
		<label for="'.$this->id.'1" >Sub menu</label>
		<input type="radio" id="'.$this->id.'2" name="'.$this->name.'" value="footer_menu" '.$checked2.' />			
		<label for="'.$this->id.'2" >Footer Menu</label>
		</fieldset>
		';
	}
}
