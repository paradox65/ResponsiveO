<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.form.formfield');
 
class JFormFieldtextem extends JFormField
{
	protected $type = 'textem';

	public function getInput()
	{
		return 	'<div class="input-append">'.
				'<input class="input-medium" type="text" name="' . $this->name . '" id="' . $this->id . '"' . ' value="'
				. htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '"/>'.
				'<span class="add-on">em</span>'.
				'</div>';
	}
}
