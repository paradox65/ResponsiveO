<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
 
jimport('joomla.form.formfield');
 
class JFormFieldRadiomenustyle extends JFormFieldRadio
{
	protected $type = 'radiomenustyle';

	public function getInput()
	{
		$checked0 = ($this->value == 'jmg-menustyle-1')? 'checked="checked"' : '';
		$checked1 = ($this->value == 'jmg-menustyle-2')? 'checked="checked"' : '';
		$checked2 = ($this->value == 'jmg-menustyle-3')? 'checked="checked"' : '';
		$checked3 = ($this->value == 'jmg-menustyle-4')? 'checked="checked"' : '';
		$checked4 = ($this->value == 'jmg-menustyle-5')? 'checked="checked"' : '';
		$checked5 = ($this->value == 'jmg-menustyle-6')? 'checked="checked"' : '';
		
		return '
		<fieldset id="'.$this->id.'" class="btn-group responsiveo radio">
		<input type="radio" id="'.$this->id.'0" name="'.$this->name.'" value="jmg-menustyle-1" '.$checked0.' />			
		<label for="'.$this->id.'0" >
		<div class="jmg-menustyle jmg-menustyle-1">
		<ul>
		<li class="active"><a href="#" >Menu 1</a></li>
		<li><a href="#" >Menu 2</a></li>
		<li><a href="#" >Menu 3</a></li>
		<li><a href="#" >Menu 4</a></li>
		<li><a href="#" >Menu 5</a></li>
		<li><a href="#" >Menu 6</a></li>
		</ul>
		</div>
		</label>
		<input type="radio" id="'.$this->id.'1" name="'.$this->name.'" value="jmg-menustyle-2" '.$checked1.' />			
		<label for="'.$this->id.'1" >
		<div class="jmg-menustyle jmg-menustyle-2">
		<ul>
		<li class="active"><a href="#" >Menu 1</a></li>
		<li><a href="#" >Menu 2</a></li>
		<li><a href="#" >Menu 3</a></li>
		<li><a href="#" >Menu 4</a></li>
		<li><a href="#" >Menu 5</a></li>
		<li><a href="#" >Menu 6</a></li>
		</ul>
		</div>
		</label>
		<input type="radio" id="'.$this->id.'2" name="'.$this->name.'" value="jmg-menustyle-3" '.$checked2.' />			
		<label for="'.$this->id.'2" >
		<div class="jmg-menustyle jmg-menustyle-3">
		<ul>
		<li class="active"><a href="#" >Menu 1</a></li>
		<li><a href="#" >Menu 2</a></li>
		<li><a href="#" >Menu 3</a></li>
		<li><a href="#" >Menu 4</a></li>
		<li><a href="#" >Menu 5</a></li>
		<li><a href="#" >Menu 6</a></li>
		</ul>
		</div>
		</label>
		<input type="radio" id="'.$this->id.'3" name="'.$this->name.'" value="jmg-menustyle-4" '.$checked3.' />			
		<label for="'.$this->id.'3" >
		<div class="jmg-menustyle-dark jmg-menustyle-4">
		<ul>
		<li class="active"><a href="#" >Menu 1</a></li>
		<li><a href="#" >Menu 2</a></li>
		<li><a href="#" >Menu 3</a></li>
		<li><a href="#" >Menu 4</a></li>
		<li><a href="#" >Menu 5</a></li>
		<li><a href="#" >Menu 6</a></li>
		</ul>
		</div>
		</label>
		<input type="radio" id="'.$this->id.'4" name="'.$this->name.'" value="jmg-menustyle-5" '.$checked4.' />			
		<label for="'.$this->id.'4" >
		<div class="jmg-menustyle-dark jmg-menustyle-5">
		<ul>
		<li class="active"><a href="#" >Menu 1</a></li>
		<li><a href="#" >Menu 2</a></li>
		<li><a href="#" >Menu 3</a></li>
		<li><a href="#" >Menu 4</a></li>
		<li><a href="#" >Menu 5</a></li>
		<li><a href="#" >Menu 6</a></li>
		</ul>
		</div>
		</label>
		<input type="radio" id="'.$this->id.'5" name="'.$this->name.'" value="jmg-menustyle-6" '.$checked5.' />			
		<label for="'.$this->id.'5" >
		<div class="jmg-menustyle-dark jmg-menustyle-6">
		<ul>
		<li class="active"><a href="#" >Menu 1</a></li>
		<li><a href="#" >Menu 2</a></li>
		<li><a href="#" >Menu 3</a></li>
		<li><a href="#" >Menu 4</a></li>
		<li><a href="#" >Menu 5</a></li>
		<li><a href="#" >Menu 6</a></li>
		</ul>
		</div>
		</label>
		</fieldset>
		';
	}
}
