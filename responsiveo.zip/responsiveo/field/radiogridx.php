<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
 
jimport('joomla.form.formfield');
 
class JFormFieldRadiogridx extends JFormFieldRadio
{
	protected $type = 'radiogridx';

	public function getInput()
	{
		$checked0 = ($this->value == '12')? 'checked="checked"' : '';
		$checked1 = ($this->value == '6_6')? 'checked="checked"' : '';
		$checked2 = ($this->value == '4_4_4')? 'checked="checked"' : '';
		$checked3 = ($this->value == '3_3_3_3')? 'checked="checked"' : '';
		$checked4 = ($this->value == '4_8')? 'checked="checked"' : '';
		$checked5 = ($this->value == '3_9')? 'checked="checked"' : '';
		$checked6 = ($this->value == '8_4')? 'checked="checked"' : '';
		$checked7 = ($this->value == '9_3')? 'checked="checked"' : '';
		$checked8 = ($this->value == '3_6_3')? 'checked="checked"' : '';
		
		return '
		<fieldset id="'.$this->id.'" class="btn-group responsiveo radio">
		<input type="radio" id="'.$this->id.'0" name="'.$this->name.'" value="12" '.$checked0.' />			
		<label for="'.$this->id.'0" ><img src="'.Juri::root().'templates/responsiveo/images/grid_12_x.png" /></label>
		<input type="radio" id="'.$this->id.'1" name="'.$this->name.'" value="6_6" '.$checked1.' />			
		<label for="'.$this->id.'1" ><img src="'.Juri::root().'templates/responsiveo/images/grid_6_6_x.png" /></label>
		<input type="radio" id="'.$this->id.'2" name="'.$this->name.'" value="4_4_4" '.$checked2.' />			
		<label for="'.$this->id.'2" ><img src="'.Juri::root().'templates/responsiveo/images/grid_4_4_4_x.png" /></label>
		<input type="radio" id="'.$this->id.'3" name="'.$this->name.'" value="3_3_3_3" '.$checked3.' />			
		<label for="'.$this->id.'3" ><img src="'.Juri::root().'templates/responsiveo/images/grid_3_3_3_3_x.png" /></label>
		<input type="radio" id="'.$this->id.'4" name="'.$this->name.'" value="4_8" '.$checked4.' />			
		<label for="'.$this->id.'4" ><img src="'.Juri::root().'templates/responsiveo/images/grid_4_8_x.png" /></label>
		<input type="radio" id="'.$this->id.'5" name="'.$this->name.'" value="3_9" '.$checked5.' />			
		<label for="'.$this->id.'5" ><img src="'.Juri::root().'templates/responsiveo/images/grid_3_9_x.png" /></label>
		<input type="radio" id="'.$this->id.'6" name="'.$this->name.'" value="8_4" '.$checked6.' />			
		<label for="'.$this->id.'6" ><img src="'.Juri::root().'templates/responsiveo/images/grid_8_4_x.png" /></label>
		<input type="radio" id="'.$this->id.'7" name="'.$this->name.'" value="9_3" '.$checked7.' />			
		<label for="'.$this->id.'7" ><img src="'.Juri::root().'templates/responsiveo/images/grid_9_3_x.png" /></label>
		<input type="radio" id="'.$this->id.'8" name="'.$this->name.'" value="3_6_3" '.$checked8.' />			
		<label for="'.$this->id.'8" ><img src="'.Juri::root().'templates/responsiveo/images/grid_3_6_3_x.png" /></label>
		</fieldset>
		';
	}
}
