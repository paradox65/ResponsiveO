<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
 
jimport('joomla.form.formfield');
 
class JFormFieldRadiogradient extends JFormFieldRadio
{
	protected $type = 'radiogradient';

	public function getInput()
	{
		$checked0 = ($this->value == 'jmg-gradient-1')? 'checked="checked"' : '';
		$checked1 = ($this->value == 'jmg-gradient-2')? 'checked="checked"' : '';
		$checked2 = ($this->value == 'jmg-gradient-3')? 'checked="checked"' : '';
		$checked3 = ($this->value == 'jmg-gradient-4')? 'checked="checked"' : '';
		$checked4 = ($this->value == 'jmg-gradient-5')? 'checked="checked"' : '';
		$checked5 = ($this->value == 'jmg-gradient-6')? 'checked="checked"' : '';
		$checked6 = ($this->value == 'jmg-gradient-7')? 'checked="checked"' : '';
		$checked7 = ($this->value == 'jmg-gradient-8')? 'checked="checked"' : '';
		$checked8 = ($this->value == 'jmg-gradient-9')? 'checked="checked"' : '';
		$checked9 = ($this->value == 'jmg-gradient-10')? 'checked="checked"' : '';
		$checked10 = ($this->value == 'jmg-gradient-11')? 'checked="checked"' : '';
		$checked11 = ($this->value == 'jmg-gradient-12')? 'checked="checked"' : '';
		$checked999 = ($this->value == 'jmg-gradient-1000')? 'checked="checked"' : '';
		$checked1000 = ($this->value == 'jmg-gradient-1001')? 'checked="checked"' : '';
		$checked1001 = ($this->value == 'jmg-gradient-1002')? 'checked="checked"' : '';
		$checked1002 = ($this->value == 'jmg-gradient-1003')? 'checked="checked"' : '';
		$checked1003 = ($this->value == 'jmg-gradient-1004')? 'checked="checked"' : '';
		
		return '
		<fieldset id="'.$this->id.'" class="btn-group responsiveo radio">
		<input type="radio" id="'.$this->id.'0" name="'.$this->name.'" value="jmg-gradient-1" '.$checked0.' />			
		<label for="'.$this->id.'0" >
		<div class="jmg-gradient jmg-gradient-1"></div>
		</label>
		<input type="radio" id="'.$this->id.'1" name="'.$this->name.'" value="jmg-gradient-2" '.$checked1.' />			
		<label for="'.$this->id.'1" >
		<div class="jmg-gradient jmg-gradient-2"></div>
		</label>
		<input type="radio" id="'.$this->id.'2" name="'.$this->name.'" value="jmg-gradient-3" '.$checked2.' />			
		<label for="'.$this->id.'2" >
		<div class="jmg-gradient jmg-gradient-3"></div>
		</label>
		<input type="radio" id="'.$this->id.'3" name="'.$this->name.'" value="jmg-gradient-4" '.$checked3.' />			
		<label for="'.$this->id.'3" >
		<div class="jmg-gradient jmg-gradient-4"></div>
		</label>
		<input type="radio" id="'.$this->id.'4" name="'.$this->name.'" value="jmg-gradient-5" '.$checked4.' />			
		<label for="'.$this->id.'4" >
		<div class="jmg-gradient jmg-gradient-5"></div>
		</label>
		<input type="radio" id="'.$this->id.'5" name="'.$this->name.'" value="jmg-gradient-6" '.$checked5.' />			
		<label for="'.$this->id.'5" >
		<div class="jmg-gradient jmg-gradient-6"></div>
		</label>
		<input type="radio" id="'.$this->id.'6" name="'.$this->name.'" value="jmg-gradient-7" '.$checked6.' />			
		<label for="'.$this->id.'6" >
		<div class="jmg-gradient jmg-gradient-7"></div>
		</label>
		<input type="radio" id="'.$this->id.'7" name="'.$this->name.'" value="jmg-gradient-8" '.$checked7.' />			
		<label for="'.$this->id.'7" >
		<div class="jmg-gradient jmg-gradient-8"></div>
		</label>
		<input type="radio" id="'.$this->id.'8" name="'.$this->name.'" value="jmg-gradient-9" '.$checked8.' />			
		<label for="'.$this->id.'8" >
		<div class="jmg-gradient jmg-gradient-9"></div>
		</label>
		<input type="radio" id="'.$this->id.'9" name="'.$this->name.'" value="jmg-gradient-10" '.$checked9.' />			
		<label for="'.$this->id.'9" >
		<div class="jmg-gradient jmg-gradient-10"></div>
		</label>
		<input type="radio" id="'.$this->id.'10" name="'.$this->name.'" value="jmg-gradient-11" '.$checked10.' />			
		<label for="'.$this->id.'10" >
		<div class="jmg-gradient jmg-gradient-11"></div>
		</label>
		<input type="radio" id="'.$this->id.'11" name="'.$this->name.'" value="jmg-gradient-12" '.$checked11.' />			
		<label for="'.$this->id.'11" >
		<div class="jmg-gradient jmg-gradient-12"></div>
		</label>
		<input type="radio" id="'.$this->id.'999" name="'.$this->name.'" value="jmg-gradient-1000" '.$checked999.' />			
		<label for="'.$this->id.'999" >
		<div class="jmg-gradient jmg-gradient-1000">Animated</div>
		</label>
		<input type="radio" id="'.$this->id.'1000" name="'.$this->name.'" value="jmg-gradient-1001" '.$checked1000.' />			
		<label for="'.$this->id.'1000" >
		<div class="jmg-gradient jmg-gradient-1001">Animated</div>
		</label>
		<input type="radio" id="'.$this->id.'1001" name="'.$this->name.'" value="jmg-gradient-1002" '.$checked1001.' />			
		<label for="'.$this->id.'1001" >
		<div class="jmg-gradient jmg-gradient-1002">Animated</div>
		</label>
		<input type="radio" id="'.$this->id.'1002" name="'.$this->name.'" value="jmg-gradient-1003" '.$checked1002.' />			
		<label for="'.$this->id.'1002" >
		<div class="jmg-gradient jmg-gradient-1003">Animated</div>
		</label>
		<input type="radio" id="'.$this->id.'1003" name="'.$this->name.'" value="jmg-gradient-1004" '.$checked1003.' />			
		<label for="'.$this->id.'1003" >
		<div class="jmg-gradient jmg-gradient-1004">Animated</div>
		</label>
		</fieldset>
		';
	}
}
