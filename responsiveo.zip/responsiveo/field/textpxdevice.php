<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.form.formfield');
 
class JFormFieldtextpxdevice extends JFormField
{
	protected $type = 'textpxdevice';

	public function getInput()
	{	
		
		$input = '<div class="jmg-input-device">
			<img src="'.Juri::root().'templates/responsiveo/images/screen.png" />
			<div class="input-append">'.
			'<input class="input-medium" type="text" name="' . $this->name . '" id="' . $this->id . '"' . ' value="'
			. htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '"/>'.
			'<span class="add-on">px</span>'.
			'</div>
		</div>
		
		<div class="jmg-input-device">
			<img src="'.Juri::root().'templates/responsiveo/images/tab_landscape.png" />
			<div class="input-append">'.
			'<input class="input-medium" type="text" name="' . $this->name . '" id="' . $this->id . '"' . ' value="'
			. htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '"/>'.
			'<span class="add-on">px</span>'.
			'</div>
		</div>
		
		<div class="jmg-input-device">
			<img src="'.Juri::root().'templates/responsiveo/images/tab_portrait.png" />
			<div class="input-append">'.
			'<input class="input-medium" type="text" name="' . $this->name . '" id="' . $this->id . '"' . ' value="'
			. htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '"/>'.
			'<span class="add-on">%</span>'.
			'</div>
		</div>
		
		<div class="jmg-input-device">
			<img src="'.Juri::root().'templates/responsiveo/images/mob_landscape.png" />
			<div class="input-append">'.
			'<input class="input-medium" type="text" name="' . $this->name . '" id="' . $this->id . '"' . ' value="'
			. htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '"/>'.
			'<span class="add-on">%</span>'.
			'</div>
		</div>
		
		<div class="jmg-input-device">
			<img src="'.Juri::root().'templates/responsiveo/images/mob_portrait.png" />
			<div class="input-append">'.
			'<input class="input-medium" type="text" name="' . $this->name . '" id="' . $this->id . '"' . ' value="'
			. htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '"/>'.
			'<span class="add-on">%</span>'.
			'</div>
		</div>
		';
		
		return $input;
	}
}
