<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.form.formfield');
 
class JFormFieldtexttablandscape extends JFormField
{
	protected $type = 'texttablandscape';

	public function getInput()
	{	
		
		return '<div class="jmg-input-device">
			<img src="'.Juri::root().'templates/responsiveo/images/tab_landscape.png" />
			<div class="input-append">'.
			'<input class="input-medium" type="text" name="' . $this->name . '" id="' . $this->id . '"' . ' value="'
			. htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '"/>'.
			'<span class="add-on">'.$this->class.'</span>'.
			'</div>
		</div>
		';

	}
}
