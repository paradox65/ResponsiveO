<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.form.formfield');
 
class JFormFieldradioscreen extends JFormField
{
	protected $type = 'radioscreen';

	public function getInput()
	{	
		$checked0 = ($this->value == '0')? 'checked="checked"' : '';
		$checked1 = ($this->value == '1')? 'checked="checked"' : '';
		
		return '<div class="jmg-input-device">
			<img src="'.Juri::root().'templates/responsiveo/images/screen.png" />
			<fieldset id="'.$this->id.'" class="btn-group radio">
			<input type="radio" id="'.$this->id.'1" name="'.$this->name.'" value="0" '.$checked0.' />			
			<label for="'.$this->id.'0" >'.JText::_('JYES').'</label>
			<input type="radio" id="'.$this->id.'0" name="'.$this->name.'" value="1" '.$checked1.' />			
			<label for="'.$this->id.'1" >'.JText::_('JNO').'</label>
			</fieldset>
		</div>
		';

	}
}
