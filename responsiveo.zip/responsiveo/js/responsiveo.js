(function($){

var $window = $(window);

function check_header() {

	var headerPlaceHolder = $('.reponsiveo-header-place-holder');
	var headerElement = $('.responsiveo-header');
	var headerHeight = headerElement.outerHeight();
	//headerPlaceHolder.css({'min-height':headerHeight});	

}
$window.on('load', check_header);
		
})(jQuery);