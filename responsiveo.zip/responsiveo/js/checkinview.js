(function($){



var $window = $(window);

function check_if_in_view() {

	var window_height = $window.height();
	var document_height = $(document).height();
  	var window_top_position = $window.scrollTop();
  	var window_bottom_position = (window_top_position + window_height);
	var animation_elements = $('.responsiveoAnimated');
	
 	$.each(animation_elements, function() {
		var $element = $(this);
		var element_height = $element.outerHeight();
    	var element_top_position = $element.offset().top;
    	var element_bottom_position = (element_top_position + element_height);
		
		if(window_top_position > element_top_position + element_height / 3 || window_bottom_position < element_top_position + element_height / 3){
			$element.removeClass('in-view');
		}
   		else{
			$element.addClass('in-view');
		}
		
	});
	
	

}


$window.on('scroll resize', check_if_in_view);
$window.trigger('scroll');
	
	
})(jQuery);