<div class="navbar-header">
     <button type="button" class="navbar-toggle x collapsed" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
     </button>
</div>
<nav class="mainmenu collapse navbar-collapse">
     <jdoc:include type="modules" name="mainmenu" style="xhtml" />
</nav><!--/.nav-collapse --> 
