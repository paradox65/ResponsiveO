<div class="responsiveo-logo">
<img style="width:<?php echo $this->params->get('logo_width')?>px; height:<?php echo $this->params->get('logo_height')?>px; " src="<?php echo $tpl_responsiveo_logo_src;?>" alt="Logo" />
</div>