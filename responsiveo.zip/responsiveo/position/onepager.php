<div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
     </button>
</div>
<nav class="mainmenu navbar-collapse collapse">

<div class="moduletable_menu">
<ul class="nav menu mainmenu">
<?php if (tpl_responsiveo_get_area_active($tpl_responsiveo_header_section_name,$lang->getTag()) == 1): ?>
<li class=""><a onclick="jQuery('html, body').animate({scrollTop : jQuery('.responsiveo-header-section').position().top}, 'slow', 'swing'); return false;" href="#" ><?php echo tpl_responsiveo_get_area_name($tpl_responsiveo_header_section_name,$lang->getTag());?></a></li>
<?php endif; ?>
<?php if (tpl_responsiveo_get_area_active($tpl_responsiveo_slider_section_name,$lang->getTag()) == 1): ?>
<li class=""><a onclick="jQuery('html, body').animate({scrollTop : jQuery('.responsiveo-slider-section').position().top - jQuery('.responsiveo-header-section').outerHeight()}, 'slow', 'swing'); return false;" href="#" ><?php echo tpl_responsiveo_get_area_name($tpl_responsiveo_slider_section_name,$lang->getTag());?></a></li>
<?php endif; ?>
<?php if (tpl_responsiveo_get_area_active($tpl_responsiveo_top_section_name,$lang->getTag()) == 1): ?>
<li class=""><a onclick="jQuery('html, body').animate({scrollTop : jQuery('.responsiveo-top-section').position().top - jQuery('.responsiveo-header-section').outerHeight()}, 'slow', 'swing'); return false;" href="#" ><?php echo tpl_responsiveo_get_area_name($tpl_responsiveo_top_section_name,$lang->getTag());?></a></li>
<?php endif; ?>
<?php if (tpl_responsiveo_get_area_active($tpl_responsiveo_content_section_name,$lang->getTag()) == 1): ?>
<li class=""><a onclick="jQuery('html, body').animate({scrollTop : jQuery('.responsiveo-content-section').position().top - jQuery('.responsiveo-header-section').outerHeight()}, 'slow', 'swing'); return false;" href="#" ><?php echo tpl_responsiveo_get_area_name($tpl_responsiveo_content_section_name,$lang->getTag());?></a></li>
<?php endif; ?>
<?php if (tpl_responsiveo_get_area_active($tpl_responsiveo_bottom_section_name,$lang->getTag()) == 1): ?>
<li class=""><a onclick="jQuery('html, body').animate({scrollTop : jQuery('.responsiveo-bottom-section').position().top - jQuery('.responsiveo-header-section').outerHeight()}, 'slow', 'swing'); return false;" href="#" ><?php echo tpl_responsiveo_get_area_name($tpl_responsiveo_bottom_section_name,$lang->getTag());?></a></li>
<?php endif; ?>
<?php if (tpl_responsiveo_get_area_active($tpl_responsiveo_footer_section_name,$lang->getTag()) == 1): ?>
<li class=""><a onclick="jQuery('html, body').animate({scrollTop : jQuery('.responsiveo-footer-section').position().top - jQuery('.responsiveo-header-section').outerHeight()}, 'slow', 'swing'); return false;" href="#" ><?php echo tpl_responsiveo_get_area_name($tpl_responsiveo_footer_section_name,$lang->getTag());?></a></li>
<?php endif; ?>
</ul>
</div>
	
</nav><!--/.nav-collapse --> 