<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<div class="col-lg-3 <?php echo $tpl_responsiveo_footer_grid363_animation->tpl_responsiveo_grid_a;?>">
	<jdoc:include type="modules" name="footer1" style="xhtml" />
</div>
<div class="col-lg-6 <?php echo $tpl_responsiveo_footer_grid363_animation->tpl_responsiveo_grid_b;?>">
	<jdoc:include type="modules" name="footer2" style="xhtml" />
</div>
<div class="col-lg-3 <?php echo $tpl_responsiveo_footer_grid363_animation->tpl_responsiveo_grid_c;?>">
	<jdoc:include type="modules" name="footer3" style="xhtml" />
</div>