<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );

$tplResponsiveoPosition = 'mainmenu';
if($tpl_responsiveo_header_grid == '12')$tplResponsiveoPosition = $tpl_responsiveo_header_grid12_settings->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '6_6')$tplResponsiveoPosition = $tpl_responsiveo_header_grid66_settings->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '4_4_4')$tplResponsiveoPosition = $tpl_responsiveo_header_grid444_settings->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '3_3_3_3')$tplResponsiveoPosition = $tpl_responsiveo_header_grid3333_settings->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '4_8')$tplResponsiveoPosition = $tpl_responsiveo_header_grid48_settings->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '3_9')$tplResponsiveoPosition = $tpl_responsiveo_header_grid39_settings->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '8_4')$tplResponsiveoPosition = $tpl_responsiveo_header_grid84_settings->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '9_3')$tplResponsiveoPosition = $tpl_responsiveo_header_grid93_settings->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '3_6_3')$tplResponsiveoPosition = $tpl_responsiveo_header_grid363_settings->tpl_responsiveo_grid_x;

$tplResponsiveoAnimation = 'none';
if($tpl_responsiveo_header_grid == '12')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid12_animation->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '6_6')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid66_animation->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '4_4_4')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid444_animation->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '3_3_3_3')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid3333_animation->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '4_8')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid48_animation->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '3_9')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid39_animation->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '8_4')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid84_animation->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '9_3')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid93_animation->tpl_responsiveo_grid_x;
if($tpl_responsiveo_header_grid == '3_6_3')$tplResponsiveoAnimation = $tpl_responsiveo_header_grid363_animation->tpl_responsiveo_grid_x;
?>
<div class="col-lg-12 <?php echo $tplResponsiveoAnimation;?>">
	<?php include (JPATH_ROOT.'/templates/responsiveo/position/'.$tplResponsiveoPosition.'.php');?>  
</div>