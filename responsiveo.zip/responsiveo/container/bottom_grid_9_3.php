<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<div class="col-lg-9">
   <jdoc:include type="modules" name="bottom1" style="xhtml" />
</div>
<div class="col-lg-3">
   <jdoc:include type="modules" name="bottom2" style="xhtml" />
</div>