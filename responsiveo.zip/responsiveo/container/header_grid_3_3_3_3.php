<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<div class="col-lg-3 <?php echo $tpl_responsiveo_header_grid3333_animation->tpl_responsiveo_grid_a;?>">
	<?php include (JPATH_ROOT.'/templates/responsiveo/position/'.$tpl_responsiveo_header_grid3333_settings->tpl_responsiveo_grid_a.'.php');?>  
</div>
<div class="col-lg-3 <?php echo $tpl_responsiveo_header_grid3333_animation->tpl_responsiveo_grid_b;?>">
    <?php include (JPATH_ROOT.'/templates/responsiveo/position/'.$tpl_responsiveo_header_grid3333_settings->tpl_responsiveo_grid_b.'.php');?>    
</div>
<div class="col-lg-3 <?php echo $tpl_responsiveo_header_grid3333_animation->tpl_responsiveo_grid_c;?>">
    <?php include (JPATH_ROOT.'/templates/responsiveo/position/'.$tpl_responsiveo_header_grid3333_settings->tpl_responsiveo_grid_c.'.php');?>    
</div>
<div class="col-lg-3 <?php echo $tpl_responsiveo_header_grid3333_animation->tpl_responsiveo_grid_d;?>">
    <?php include (JPATH_ROOT.'/templates/responsiveo/position/'.$tpl_responsiveo_header_grid3333_settings->tpl_responsiveo_grid_d.'.php');?>    
</div>