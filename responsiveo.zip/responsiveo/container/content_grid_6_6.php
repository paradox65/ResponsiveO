<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
        	<?php if ($this->countModules('sidebarleft')): ?>
                    <div class="col-lg-6 sidebarleft <?php echo $tpl_responsiveo_content_grid66_animation->tpl_responsiveo_grid_a;?>">
                         <jdoc:include type="modules" name="sidebarleft" style="xhtml" />
                    </div>
            <?php endif; ?>
        	<div class="<?php if($this->countModules('sidebarleft') || $this->countModules('sidebarright'))echo 'col-lg-6'; 
				else echo 'col-lg-12';?> <?php echo $tpl_responsiveo_content_grid66_animation->tpl_responsiveo_grid_b;?>">
            	<jdoc:include type="message" />
            	<jdoc:include type="modules" name="headline" style="xhtml" />
            	<jdoc:include type="component" />
            </div>
            <?php if ($this->countModules('sidebarright')): ?>
                    <div class="col-lg-6 sidebarright  <?php echo $tpl_responsiveo_content_grid66_animation->tpl_responsiveo_grid_b;?>">
                        <jdoc:include type="modules" name="sidebarright" style="xhtml" />
                    </div>
            <?php endif; ?>