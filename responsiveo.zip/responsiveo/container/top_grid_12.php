<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<div class="col-lg-12">
	<?php include (JPATH_ROOT.'/templates/responsiveo/position/'.$tpl_responsiveo_top_grid12_settings->tpl_responsiveo_grid_a.'.php');?>  
</div>