<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<div class="col-lg-12 <?php echo $tpl_responsiveo_content_grid12_animation->tpl_responsiveo_grid_a;?>">
      <jdoc:include type="message" />
      <jdoc:include type="modules" name="headline" style="xhtml" />
      <jdoc:include type="component" />
</div>