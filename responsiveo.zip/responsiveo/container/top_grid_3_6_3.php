<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<div class="col-lg-3">
   <jdoc:include type="modules" name="top1" style="xhtml" />
</div>
<div class="col-lg-6">
   <jdoc:include type="modules" name="top2" style="xhtml" />
</div>
<div class="col-lg-3">
   <jdoc:include type="modules" name="top3" style="xhtml" />
</div>