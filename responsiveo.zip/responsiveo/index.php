<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/

defined( '_JEXEC' ) or die( 'Restricted access' );

$app  = JFactory::getApplication();
$doc  = JFactory::getDocument();
$lang = JFactory::getLanguage();
$article = JTable::getInstance("content"); 
$article_id = JFactory::getApplication()->input->get('id'); // Get Article ID 
$params = $app->getTemplate(true)->params;
$tpl_responsiveo_bootstrap_default_load = $params->get('tpl_responsiveo_bootstrap_default_load');
$tpl_responsiveo_onepager = $params->get('tpl_responsiveo_onepager');
$tpl_responsiveo_google_fonts_load = $params->get('tpl_responsiveo_google_fonts_load');
$tpl_responsiveo_google_fonts_url = $params->get('tpl_responsiveo_google_fonts_url');
$tpl_responsiveo_logo_use_svg = $params->get('tpl_responsiveo_logo_use_svg');
$tpl_responsiveo_use_hover_css = $params->get('tpl_responsiveo_use_hover_css');
if($tpl_responsiveo_logo_use_svg == 1)$tpl_responsiveo_logo_src = $params->get('tpl_responsiveo_svg_logo_path');
else $tpl_responsiveo_logo_src = $params->get('tpl_responsiveo_logo_img');
if($tpl_responsiveo_logo_src == '')$tpl_responsiveo_logo_src = Juri::base().'/templates/responsiveo/images/logo.png';
$tpl_responsiveo_show_infobar = $params->get('tpl_responsiveo_show_infobar');
$tpl_responsiveo_infobar_container = $params->get('tpl_responsiveo_infobar_container');
$tpl_responsiveo_infobar_phone = $params->get('tpl_responsiveo_infobar_phone');
$tpl_responsiveo_infobar_mail = $params->get('tpl_responsiveo_infobar_mail');
$tpl_responsiveo_main_menu_collapse = $params->get('tpl_responsiveo_main_menu_collapse');
$tpl_responsiveo_main_menu_style = $params->get('tpl_responsiveo_main_menu_style');
$tpl_responsiveo_main_menu_padding = $params->get('tpl_responsiveo_main_menu_padding');
$tpl_responsiveo_main_menu_hover_bgcolor = $params->get('tpl_responsiveo_main_menu_hover_bgcolor');
$tpl_responsiveo_header_section_name = $params->get('tpl_responsiveo_header_section_name');
$tpl_responsiveo_header_grid_expand = $params->get('tpl_responsiveo_header_grid_expand');
$tpl_responsiveo_header_grid = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid') : $params->get('tpl_responsiveo_header_grid_expanded');
$tpl_responsiveo_header_grid12_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid12_settings') : $params->get('tpl_responsiveo_header_grid12x_settings');
$tpl_responsiveo_header_grid66_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid66_settings') : $params->get('tpl_responsiveo_header_grid66x_settings');
$tpl_responsiveo_header_grid444_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid444_settings') : $params->get('tpl_responsiveo_header_grid444x_settings');
$tpl_responsiveo_header_grid3333_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid3333_settings') : $params->get('tpl_responsiveo_header_grid3333x_settings');
$tpl_responsiveo_header_grid48_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid48_settings') : $params->get('tpl_responsiveo_header_grid48x_settings');
$tpl_responsiveo_header_grid39_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid39_settings') : $params->get('tpl_responsiveo_header_grid39x_settings');
$tpl_responsiveo_header_grid84_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid84_settings') : $params->get('tpl_responsiveo_header_grid84x_settings');
$tpl_responsiveo_header_grid93_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid93_settings') : $params->get('tpl_responsiveo_header_grid93x_settings');
$tpl_responsiveo_header_grid363_settings = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid363_settings') : $params->get('tpl_responsiveo_header_grid363x_settings');
$tpl_responsiveo_header_grid12_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid12_animation') : $params->get('tpl_responsiveo_header_grid12x_animation');
$tpl_responsiveo_header_grid66_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid66_animation') : $params->get('tpl_responsiveo_header_grid66x_animation');
$tpl_responsiveo_header_grid444_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid444_animation') : $params->get('tpl_responsiveo_header_grid444x_animation');
$tpl_responsiveo_header_grid3333_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid3333_animation') : $params->get('tpl_responsiveo_header_grid3333x_animation');
$tpl_responsiveo_header_grid48_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid48_animation') : $params->get('tpl_responsiveo_header_grid48x_animation');
$tpl_responsiveo_header_grid39_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid39_animation') : $params->get('tpl_responsiveo_header_grid39x_animation');
$tpl_responsiveo_header_grid84_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid84_animation') : $params->get('tpl_responsiveo_header_grid84x_animation');
$tpl_responsiveo_header_grid93_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid93_animation') : $params->get('tpl_responsiveo_header_grid93x_animation');
$tpl_responsiveo_header_grid363_animation = ($tpl_responsiveo_header_grid_expand == 0)? $params->get('tpl_responsiveo_header_grid363_animation') : $params->get('tpl_responsiveo_header_grid363x_animation');
$tpl_responsiveo_header_height = $params->get('tpl_responsiveo_header_height');
$tpl_responsiveo_header_bgmedia = $params->get('tpl_responsiveo_header_bgmedia');
$tpl_responsiveo_header_bgmedia_youtube_id = $params->get('tpl_responsiveo_header_bgmedia_youtube_id');
$tpl_responsiveo_header_bgmedia_youtube_copyright = $params->get('tpl_responsiveo_header_bgmedia_youtube_copyright');
$tpl_responsiveo_header_bgmedia_gradient = ($tpl_responsiveo_header_bgmedia == 'gradient')? $params->get('tpl_responsiveo_header_bgmedia_gradient') : '';
$tpl_responsiveo_header_container = $params->get('tpl_responsiveo_header_container');
$tpl_responsiveo_header_container_vertical_alignment = $params->get('tpl_responsiveo_header_container_vertical_alignment');
$tpl_responsiveo_header_display = $params->get('tpl_responsiveo_header_display');
$tpl_responsiveo_slider_section_name = $params->get('tpl_responsiveo_slider_section_name');
$tpl_responsiveo_slider_section_name = $params->get('tpl_responsiveo_slider_section_name');
$tpl_responsiveo_slider_bgmedia = $params->get('tpl_responsiveo_slider_bgmedia');
$tpl_responsiveo_slider_bgmedia_youtube_id = $params->get('tpl_responsiveo_slider_bgmedia_youtube_id');
$tpl_responsiveo_slider_bgmedia_youtube_copyright = $params->get('tpl_responsiveo_slider_bgmedia_youtube_copyright');
$tpl_responsiveo_slider_bgmedia_gradient = ($tpl_responsiveo_slider_bgmedia == 'gradient')? $params->get('tpl_responsiveo_slider_bgmedia_gradient') : '';
$tpl_responsiveo_slider_container = $params->get('tpl_responsiveo_slider_container');
$tpl_responsiveo_slider_divider = $params->get('tpl_responsiveo_slider_divider');
$tpl_responsiveo_top_section_name = $params->get('tpl_responsiveo_top_section_name');
$tpl_responsiveo_top_section_name = $params->get('tpl_responsiveo_top_section_name');
$tpl_responsiveo_top_grid = $params->get('tpl_responsiveo_top_grid');
$tpl_responsiveo_top_grid12_settings = $params->get('tpl_responsiveo_top_grid12_settings');
$tpl_responsiveo_top_grid66_settings = $params->get('tpl_responsiveo_top_grid66_settings');
$tpl_responsiveo_top_grid444_settings = $params->get('tpl_responsiveo_top_grid444_settings');
$tpl_responsiveo_top_grid3333_settings = $params->get('tpl_responsiveo_top_grid3333_settings');
$tpl_responsiveo_top_grid48_settings = $params->get('tpl_responsiveo_top_grid48_settings');
$tpl_responsiveo_top_grid39_settings = $params->get('tpl_responsiveo_top_grid39_settings');
$tpl_responsiveo_top_grid84_settings = $params->get('tpl_responsiveo_top_grid84_settings');
$tpl_responsiveo_top_grid93_settings = $params->get('tpl_responsiveo_top_grid93_settings');
$tpl_responsiveo_top_grid363_settings = $params->get('tpl_responsiveo_top_grid363_settings');
$tpl_responsiveo_top_container = $params->get('tpl_responsiveo_top_container');
$tpl_responsiveo_content_section_name = $params->get('tpl_responsiveo_content_section_name');
$tpl_responsiveo_content_section_name = $params->get('tpl_responsiveo_content_section_name');
$tpl_responsiveo_content_grid = $params->get('tpl_responsiveo_content_grid');
$tpl_responsiveo_content_grid12_animation = $params->get('tpl_responsiveo_content_grid12_animation');
$tpl_responsiveo_content_grid66_animation = $params->get('tpl_responsiveo_content_grid66_animation');
$tpl_responsiveo_content_grid444_animation = $params->get('tpl_responsiveo_content_grid444_animation');
$tpl_responsiveo_content_grid3333_animation = $params->get('tpl_responsiveo_content_grid3333_animation');
$tpl_responsiveo_content_grid48_animation = $params->get('tpl_responsiveo_content_grid48_animation');
$tpl_responsiveo_content_grid39_animation = $params->get('tpl_responsiveo_content_grid39_animation');
$tpl_responsiveo_content_grid84_animation = $params->get('tpl_responsiveo_content_grid84_animation');
$tpl_responsiveo_content_grid93_animation = $params->get('tpl_responsiveo_content_grid93_animation');
$tpl_responsiveo_content_grid363_animation = $params->get('tpl_responsiveo_content_grid363_animation');
$tpl_responsiveo_content_bgcolor = $params->get('tpl_responsiveo_content_bgcolor');
$tpl_responsiveo_content_container = $params->get('tpl_responsiveo_content_container');
$tpl_responsiveo_content_border = $params->get('tpl_responsiveo_content_border');
$tpl_responsiveo_content_border_width = $params->get('tpl_responsiveo_content_border_width');
$tpl_responsiveo_content_border_color = $params->get('tpl_responsiveo_content_border_color');
$tpl_responsiveo_content_border_top_style = ($tpl_responsiveo_content_border == 1)? $tpl_responsiveo_content_border_width->tpl_responsiveo_border_top.'px solid '.$tpl_responsiveo_content_border_color : 'none';
$tpl_responsiveo_content_border_bottom_style = ($tpl_responsiveo_content_border == 1)? $tpl_responsiveo_content_border_width->tpl_responsiveo_border_bottom.'px solid '.$tpl_responsiveo_content_border_color : 'none';
$tpl_responsiveo_content_border_left_style = ($tpl_responsiveo_content_border == 1)? $tpl_responsiveo_content_border_width->tpl_responsiveo_border_left.'px solid '.$tpl_responsiveo_content_border_color : 'none';
$tpl_responsiveo_content_border_right_style = ($tpl_responsiveo_content_border == 1)? $tpl_responsiveo_content_border_width->tpl_responsiveo_border_right.'px solid '.$tpl_responsiveo_content_border_color : 'none';
$tpl_responsiveo_content_column_count = $params->get('tpl_responsiveo_content_column_count');
$tpl_responsiveo_content_column_rule = ($tpl_responsiveo_content_column_count != 1)? $params->get('tpl_responsiveo_content_column_rule') : 'none';
$tpl_responsiveo_bottom_section_name = $params->get('tpl_responsiveo_bottom_section_name');
$tpl_responsiveo_bottom_section_name = $params->get('tpl_responsiveo_bottom_section_name');
$tpl_responsiveo_bottom_grid = $params->get('tpl_responsiveo_bottom_grid');
$tpl_responsiveo_bottom_container = $params->get('tpl_responsiveo_bottom_container');
$tpl_responsiveo_footer_section_name = $params->get('tpl_responsiveo_footer_section_name');
$tpl_responsiveo_footer_section_name = $params->get('tpl_responsiveo_footer_section_name');
$tpl_responsiveo_footer_grid = $params->get('tpl_responsiveo_footer_grid');
$tpl_responsiveo_footer_grid12_animation = $params->get('tpl_responsiveo_footer_grid12_animation');
$tpl_responsiveo_footer_grid66_animation = $params->get('tpl_responsiveo_footer_grid66_animation');
$tpl_responsiveo_footer_grid444_animation = $params->get('tpl_responsiveo_footer_grid444_animation');
$tpl_responsiveo_footer_grid3333_animation = $params->get('tpl_responsiveo_footer_grid3333_animation');
$tpl_responsiveo_footer_grid48_animation = $params->get('tpl_responsiveo_footer_grid48_animation');
$tpl_responsiveo_footer_grid39_animation = $params->get('tpl_responsiveo_footer_grid39_animation');
$tpl_responsiveo_footer_grid84_animation = $params->get('tpl_responsiveo_footer_grid84_animation');
$tpl_responsiveo_footer_grid93_animation = $params->get('tpl_responsiveo_footer_grid93_animation');
$tpl_responsiveo_footer_grid363_animation = $params->get('tpl_responsiveo_footer_grid363_animation');
$tpl_responsiveo_footer_bgmedia = $params->get('tpl_responsiveo_footer_bgmedia');
$tpl_responsiveo_footer_container = $params->get('tpl_responsiveo_footer_container');
$tpl_responsiveo_footer_show_copyright = $params->get('tpl_responsiveo_footer_show_copyright');
$tpl_responsiveo_footer_copyright = $params->get('tpl_responsiveo_footer_copyright');
$tpl_responsiveo_footer_copyright_url = $params->get('tpl_responsiveo_footer_copyright_url');
$tpl_responsiveo_google_analytics = $params->get('tpl_responsiveo_google_analytics');

function tpl_responsiveo_get_area_name($sectionNameObject,$site_language){
	foreach($sectionNameObject as $obj){
		if($obj->tpl_responsiveo_site_language == $site_language){
			return $obj->tpl_responsiveo_section_name;
		}	
	}
}

function tpl_responsiveo_get_area_active($sectionNameObject,$site_language){
	foreach($sectionNameObject as $obj){
		if($obj->tpl_responsiveo_site_language == $site_language){
			return $obj->tpl_responsiveo_section_menu_active;
		}	
	}
}

//$doc->addScript('http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js');
$doc->addScript($this->baseurl."/templates/".$this->template."/js/checkinview.js");
$doc->addScript($this->baseurl."/templates/".$this->template."/js/smoothscroll.js");
$doc->addScript($this->baseurl."/templates/".$this->template."/js/responsiveo.js");

$doc->addStyleSheet($this->baseurl."/templates/".$this->template."/css/reset.css");
if($tpl_responsiveo_bootstrap_default_load == 1)$doc->addStyleSheet($this->baseurl."/templates/".$this->template."/bootstrap/css/bootstrap.css");
$doc->addStyleSheet($this->baseurl."/templates/".$this->template."/css/layout.css");
$doc->addStyleSheet($this->baseurl."/templates/".$this->template."/css/template.css.php?article_id=".$article_id);
$doc->addStyleSheet($this->baseurl."/templates/".$this->template."/css/animation.css");
$doc->addStyleSheet($this->baseurl."/templates/".$this->template."/css/gradient.css");
$doc->addStyleSheet($this->baseurl."/templates/".$this->template."/css/".$tpl_responsiveo_main_menu_style.".css");
if($tpl_responsiveo_use_hover_css == 1){
	$doc->addStyleSheet($this->baseurl."/templates/".$this->template."/css/hover.css");
}

//$doc->addScript($this->baseurl."/templates/".$this->template."/bootstrap/js/bootstrap.js");

$headeryoutubescript = '
	var tag = document.createElement("script");

    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName("script")[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
	  
	playerDefaults = {
	  	autoplay: 1, 
		autohide: 1, 
		modestbranding: 0, 
		rel: 0, 
		wmode: "opaque",
		showinfo: 0, 
		controls: 0, 
		disablekb: 1, 
		enablejsapi: 0, 
		iv_load_policy: 3,
		loop: 1
	};
	var player_header_youtube;
		
	var player_header_youtubeID = "'.$tpl_responsiveo_header_bgmedia_youtube_id.'";
		

      function onYouTubeIframeAPIReady() {
        player_header_youtube = new YT.Player("player_header_youtube", {
			  height: "100%",
			  width: "100%",
			  "videoId": player_header_youtubeID,
			  "suggestedQuality": "hd720",
			  events: {
				"onReady": onPlayerReadymod_player_header_youtube,
				"onStateChange": onPlayerStateChangemod_player_header_youtube
			  },
			  playerVars: playerDefaults
			});	
      }
	  
	  function onPlayerReadymod_player_header_youtube() {
			player_header_youtube.loadVideoById(player_header_youtubeID);
			player_header_youtube.mute();
		  }
		
	  function onPlayerStateChangemod_player_header_youtube(event) {
			if (event.data === YT.PlayerState.ENDED) {
				player_header_youtube.loadVideoById(player_header_youtubeID);
			}
		  }
';

if($tpl_responsiveo_header_bgmedia == 'youtube') $doc->addScriptDeclaration( $headeryoutubescript );

$slideryoutubescript = '
	var tag = document.createElement("script");

    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName("script")[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
	  
	playerDefaults = {
	  	autoplay: 1, 
		autohide: 1, 
		modestbranding: 0, 
		rel: 0, 
		wmode: "opaque",
		showinfo: 0, 
		controls: 0, 
		disablekb: 1, 
		enablejsapi: 0, 
		iv_load_policy: 3,
		loop: 1
	};
	var player_slider_youtube;
		
	var player_slider_youtubeID = "'.$tpl_responsiveo_slider_bgmedia_youtube_id.'";
		

      function onYouTubeIframeAPIReady() {
        player_slider_youtube = new YT.Player("player_slider_youtube", {
			  height: "100%",
			  width: "100%",
			  "videoId": player_slider_youtubeID,
			  "suggestedQuality": "hd720",
			  events: {
				"onReady": onPlayerReadymod_player_slider_youtube,
				"onStateChange": onPlayerStateChangemod_player_slider_youtube
			  },
			  playerVars: playerDefaults
			});	
      }
	  
	  function onPlayerReadymod_player_slider_youtube() {
			player_slider_youtube.loadVideoById(player_slider_youtubeID);
			player_slider_youtube.mute();
		  }
		
	  function onPlayerStateChangemod_player_slider_youtube(event) {
			if (event.data === YT.PlayerState.ENDED) {
				player_slider_youtube.loadVideoById(player_slider_youtubeID);
			}
		  }
';

if($tpl_responsiveo_slider_bgmedia == 'youtube') $doc->addScriptDeclaration( $slideryoutubescript );

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >
    
    <head>
    	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
        <jdoc:include type="head" />
        <?php if ($tpl_responsiveo_google_fonts_load == 1): ?>
        <link href='<?php echo $tpl_responsiveo_google_fonts_url;?>' rel='stylesheet' type='text/css'>
        <?php endif; ?>
        <?php echo $tpl_responsiveo_google_analytics;?>
    </head>

<?php
  $itemid = JRequest::getVar('Itemid');
  $menu = $app->getMenu();
  $active = $menu->getItem($itemid);
  $params = $menu->getParams( $active->id );
  $pageclass = $params->get( 'pageclass_sfx' );
  $tpl_responsiveo_page_class = ($pageclass) ? 'page_bg '.$pageclass : 'page_bg';
?>

<body class="<?php echo $tpl_responsiveo_page_class;?> <?php echo $tpl_responsiveo_body_bgmedia_gradient;?>">
   <div class="reponsiveo-header-place-holder">
    <header class="responsiveo-header responsiveo-header-section <?php echo $tpl_responsiveo_header_display;?> <?php echo $tpl_responsiveo_header_bgmedia_gradient;?>" role="navigation">
    	<?php if ($tpl_responsiveo_show_infobar == 1): ?>
    		<div class="responsiveo-infobar">
			<div class="<?php echo $tpl_responsiveo_infobar_container;?>">
				<div class="row">
					<?php include (JPATH_ROOT.'/templates/responsiveo/container/infobar_grid_6_6.php');?>
				</div>
			</div>
		</div>
    	<?php endif; ?>
    	<?php if ($tpl_responsiveo_header_bgmedia == 'youtube'): ?>
    	<div class="responsiveo-header-video-wrapper">
			<div class="responsiveo-header-video"><div id="player_header_youtube"></div><div class="youtube-copywright"><?php echo $tpl_responsiveo_header_bgmedia_youtube_copyright; ?></div></div>
		</div>
    	<?php endif; ?>
    	  
		<div class="responsiveo-header-wrapper">
		  <div class="<?php echo $tpl_responsiveo_header_container;?>">
			<div class="row">      	
				<?php include (JPATH_ROOT.'/templates/responsiveo/container/header_grid_'.$tpl_responsiveo_header_grid.'.php');?>
			</div>
			<?php if ($tpl_responsiveo_header_grid_expand == 1): ?>
			<div class="row">      	
				<?php include (JPATH_ROOT.'/templates/responsiveo/container/header_grid_x.php');?>
			</div>
			<?php endif; ?>
		  </div>
		</div>
    </header>
   </div>
    
    <?php if ($this->countModules('slider')): ?>
    <div class="responsiveo-slider responsiveo-slider-section <?php echo $tpl_responsiveo_slider_bgmedia_gradient;?>">
    	<?php if ($tpl_responsiveo_slider_bgmedia == 'youtube'): ?>
		<div class="responsiveo-slider-video"><div id="player_slider_youtube"></div><div class="youtube-copywright"><?php echo $tpl_responsiveo_slider_bgmedia_youtube_copyright; ?></div></div>
    	<?php endif; ?>
    	<div class="responsiveo-slider-wrapper">
    	<?php if ($tpl_responsiveo_slider_divider != 'none'): ?>
    	<div class="responsiveo-bottom-divider">
    		<?php include (JPATH_ROOT.'/templates/responsiveo/container/divider.php');?>
		</div>
    	<?php endif; ?>
			<div class="<?php echo $tpl_responsiveo_slider_container;?>">
				<div class="row">
					<?php include (JPATH_ROOT.'/templates/responsiveo/container/slider_grid_12.php');?>
				</div>
			</div>
		</div>
    </div>
    <?php endif; ?>
    
    <?php if ($this->countModules($tpl_responsiveo_top_grid12_settings->tpl_responsiveo_grid_a)): ?>
    <div class="responsiveo-top responsiveo-top-section">
    	<div class="responsiveo-top-wrapper">
			<div class="<?php echo $tpl_responsiveo_top_container;?>">
				<div class="row">
					<?php include (JPATH_ROOT.'/templates/responsiveo/container/top_grid_'.$tpl_responsiveo_top_grid.'.php');?>
				</div>
			</div>
		</div>
    </div>
    <?php endif; ?>
   
    <div class="responsiveo-content responsiveo-content-section">
    	<div class="<?php echo $tpl_responsiveo_content_container;?>">
			<div class="row">
				<?php include (JPATH_ROOT.'/templates/responsiveo/container/content_grid_'.$tpl_responsiveo_content_grid.'.php');?>
			</div>
		</div>
    </div>
    
    <?php if ($this->countModules('bottom1') || $this->countModules('bottom2') || $this->countModules('bottom3') || $this->countModules('bottom4')): ?>
    <div class="responsiveo-bottom responsiveo-bottom-section">
    	<div class="responsiveo-bottom-wrapper">
			<div class="<?php echo $tpl_responsiveo_bottom_container;?>">
				<div class="row">
					<?php include (JPATH_ROOT.'/templates/responsiveo/container/bottom_grid_'.$tpl_responsiveo_bottom_grid.'.php');?>
				</div>
			</div>
		</div>
    </div>
    <?php endif; ?>
    
    <div class="responsiveo-footer responsiveo-footer-section">
    	<div class="responsiveo-footer-wrapper">
			<div class="<?php echo $tpl_responsiveo_footer_container;?>">
				<?php if ($tpl_responsiveo_footer_show_copyright == 1): ?>
				<div class="responsiveo-copyright">

				</div>
				<?php endif; ?>
				<div class="row">
					<?php include (JPATH_ROOT.'/templates/responsiveo/container/footer_grid_'.$tpl_responsiveo_footer_grid.'.php');?>
				</div>
			</div>
		</div>
    </div>
<script src="/templates/responsiveo/bootstrap/js/bootstrap.js" type="text/javascript"></script>
</body>
</html>