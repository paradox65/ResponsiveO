<?php
/**
 * @author      Otto Szekeres
 * @package     Joomla!
 * @subpackage  Template ResponsiveO
 * @link        https://joomega.com
 * @email       info@joomega.com
 * @copyright   Otto Szekeres
 *
 * Template ResponsiveO Joomla 3.3
 * Copyright (C) 2015 - 2017 Otto Szekeres
 *
**/
header("Content-type: text/css");

define( '_JEXEC', 1 );
define('JPATH_BASE', '../../../');
require_once ( JPATH_BASE .'/includes/defines.php' );
require_once ( JPATH_BASE .'/includes/framework.php' );

/* Create the Application */
$mainframe =& JFactory::getApplication('site');
$mainframe->initialise();
$params = JFactory::getApplication()->getTemplate(true)->params;

$tpl_responsiveo_container_width = $params->get('tpl_responsiveo_container_width');
$tpl_responsiveo_body_color = $params->get('tpl_responsiveo_body_color');
$tpl_responsiveo_body_bgmedia = $params->get('tpl_responsiveo_body_bgmedia');
$tpl_responsiveo_body_bgmedia_gradient = ($tpl_responsiveo_body_bgmedia == 'gradient')? $params->get('tpl_responsiveo_body_bgmedia_gradient') : '';
$tpl_responsiveo_body_bgmedia_image = $params->get('tpl_responsiveo_body_bgmedia_image');
$tpl_responsiveo_body_bgmedia_image_repeat = $params->get('tpl_responsiveo_body_bgmedia_image_repeat');
$tpl_responsiveo_body_bgmedia_image_size = $params->get('tpl_responsiveo_body_bgmedia_image_size');
$tpl_responsiveo_body_bgimage = ($tpl_responsiveo_body_bgmedia == 'image')? ' url('.JPATH_SITE.$tpl_responsiveo_body_bgmedia_image.') '.$tpl_responsiveo_body_bgmedia_image_repeat : '';
$tpl_responsiveo_default_font_family = $params->get('tpl_responsiveo_default_font_family');
$tpl_responsiveo_font_color = $params->get('tpl_responsiveo_font_color');
$tpl_responsiveo_font_size = $params->get('tpl_responsiveo_font_size');
$tpl_responsiveo_line_height = $params->get('tpl_responsiveo_line_height');
$tpl_responsiveo_google_fonts_load = $params->get('tpl_responsiveo_google_fonts_load');
$tpl_responsiveo_google_fonts_url = $params->get('tpl_responsiveo_google_fonts_url');
$tpl_responsiveo_heading_font_family = $params->get('tpl_responsiveo_heading_font_family');
$tpl_responsiveo_heading_font_color = $params->get('tpl_responsiveo_heading_font_color');
$tpl_responsiveo_h1_font_size = $params->get('tpl_responsiveo_h1_font_size');
$tpl_responsiveo_h2_font_size = $params->get('tpl_responsiveo_h2_font_size');
$tpl_responsiveo_h3_font_size = $params->get('tpl_responsiveo_h3_font_size');
$tpl_responsiveo_h4_font_size = $params->get('tpl_responsiveo_h4_font_size');
$tpl_responsiveo_menu_font_size = $params->get('tpl_responsiveo_menu_font_size');
$tpl_responsiveo_infobar_bgcolor = $params->get('tpl_responsiveo_infobar_bgcolor');
$tpl_responsiveo_infobar_phone = $params->get('tpl_responsiveo_infobar_phone');
$tpl_responsiveo_infobar_mail = $params->get('tpl_responsiveo_infobar_mail');
$tpl_responsiveo_main_menu_collapse = $params->get('tpl_responsiveo_main_menu_collapse');
$tpl_responsiveo_main_menu_style = $params->get('tpl_responsiveo_main_menu_style');
$tpl_responsiveo_main_menu_padding = $params->get('tpl_responsiveo_main_menu_padding');
$tpl_responsiveo_main_menu_hover_bgcolor = $params->get('tpl_responsiveo_main_menu_hover_bgcolor');
$tpl_responsiveo_header_height = $params->get('tpl_responsiveo_header_height');
$tpl_responsiveo_header_bgmedia = $params->get('tpl_responsiveo_header_bgmedia');
$tpl_responsiveo_header_bgcolor = ($tpl_responsiveo_header_bgmedia != 'gradient')? $params->get('tpl_responsiveo_header_bgcolor') : '';
$tpl_responsiveo_header_bgmedia_image = $params->get('tpl_responsiveo_header_bgmedia_image');
$tpl_responsiveo_header_bgmedia_image_src = $params->get('tpl_responsiveo_header_bgmedia_image_src');
$tpl_responsiveo_header_bgmedia_image_repeat = $params->get('tpl_responsiveo_header_bgmedia_image_repeat');
$tpl_responsiveo_header_bgmedia_image_size = ($tpl_responsiveo_header_bgmedia != 'gradient')? $params->get('tpl_responsiveo_header_bgmedia_image_size') : '';
$tpl_responsiveo_header_bgimage = ($tpl_responsiveo_header_bgmedia == 'image')? (($tpl_responsiveo_header_bgmedia_image_src == 'custom')? ' url('.JPATH_SITE.$tpl_responsiveo_header_bgmedia_image.') '.$tpl_responsiveo_header_bgmedia_image_repeat.' '.$tpl_responsiveo_header_bgmedia_image_vertical_alignment : ' url('.JPATH_SITE.tpl_responsiveo_article_image($tpl_responsiveo_header_bgmedia_image_src).') '.$tpl_responsiveo_header_bgmedia_image_repeat.' '.$tpl_responsiveo_header_bgmedia_image_vertical_alignment): '';
$tpl_responsiveo_header_bgmedia_youtube_id = $params->get('tpl_responsiveo_header_bgmedia_youtube_id');
$tpl_responsiveo_header_bgmedia_youtube_copyright = $params->get('tpl_responsiveo_header_bgmedia_youtube_copyright');
$tpl_responsiveo_header_bgmedia_gradient = ($tpl_responsiveo_header_bgmedia == 'gradient')? $params->get('tpl_responsiveo_header_bgmedia_gradient') : '';
$tpl_responsiveo_header_container = $params->get('tpl_responsiveo_header_container');
$tpl_responsiveo_header_container_vertical_alignment = $params->get('tpl_responsiveo_header_container_vertical_alignment');
$tpl_responsiveo_header_border = $params->get('tpl_responsiveo_header_border');
$tpl_responsiveo_header_border_width = $params->get('tpl_responsiveo_header_border_width');
$tpl_responsiveo_header_border_color = $params->get('tpl_responsiveo_header_border_color');
$tpl_responsiveo_header_border_top_style = ($tpl_responsiveo_header_border == 1)? $tpl_responsiveo_header_border_width->tpl_responsiveo_border_top.'px solid '.$tpl_responsiveo_header_border_color : 'none';
$tpl_responsiveo_header_border_bottom_style = ($tpl_responsiveo_header_border == 1)? $tpl_responsiveo_header_border_width->tpl_responsiveo_border_bottom.'px solid '.$tpl_responsiveo_header_border_color : 'none';
$tpl_responsiveo_header_border_left_style = ($tpl_responsiveo_header_border == 1)? $tpl_responsiveo_header_border_width->tpl_responsiveo_border_left.'px solid '.$tpl_responsiveo_header_border_color : 'none';
$tpl_responsiveo_header_border_right_style = ($tpl_responsiveo_header_border == 1)? $tpl_responsiveo_header_border_width->tpl_responsiveo_border_right.'px solid '.$tpl_responsiveo_header_border_color : 'none';
$tpl_responsiveo_header_display = $params->get('tpl_responsiveo_header_display');
$tpl_responsiveo_header_padding = $params->get('tpl_responsiveo_header_padding');
$tpl_responsiveo_slider_height = $params->get('tpl_responsiveo_slider_height');
$tpl_responsiveo_slider_bgmedia = $params->get('tpl_responsiveo_slider_bgmedia');
$tpl_responsiveo_slider_bgcolor = ($tpl_responsiveo_slider_bgmedia != 'gradient')? $params->get('tpl_responsiveo_slider_bgcolor') : '';
$tpl_responsiveo_slider_bgmedia_image = $params->get('tpl_responsiveo_slider_bgmedia_image');
$tpl_responsiveo_slider_bgmedia_image_src = $params->get('tpl_responsiveo_slider_bgmedia_image_src');
$tpl_responsiveo_slider_bgmedia_image_repeat = $params->get('tpl_responsiveo_slider_bgmedia_image_repeat');
$tpl_responsiveo_slider_bgmedia_image_size = ($tpl_responsiveo_slider_bgmedia != 'gradient')? $params->get('tpl_responsiveo_slider_bgmedia_image_size') : '';
$tpl_responsiveo_slider_bgmedia_image_vertical_alignment = $params->get('tpl_responsiveo_slider_bgmedia_image_vertical_alignment');
$tpl_responsiveo_slider_bgimage = ($tpl_responsiveo_slider_bgmedia == 'image')? (($tpl_responsiveo_slider_bgmedia_image_src == 'custom')? ' url('.JPATH_SITE.$tpl_responsiveo_slider_bgmedia_image.') '.$tpl_responsiveo_slider_bgmedia_image_repeat.' '.$tpl_responsiveo_slider_bgmedia_image_vertical_alignment : ' url('.JPATH_SITE.tpl_responsiveo_article_image($tpl_responsiveo_slider_bgmedia_image_src).') '.$tpl_responsiveo_slider_bgmedia_image_repeat.' '.$tpl_responsiveo_slider_bgmedia_image_vertical_alignment): '';
$tpl_responsiveo_slider_bgmedia_youtube_id = $params->get('tpl_responsiveo_slider_bgmedia_youtube_id');
$tpl_responsiveo_slider_bgmedia_youtube_copyright = $params->get('tpl_responsiveo_slider_bgmedia_youtube_copyright');
$tpl_responsiveo_slider_bgmedia_gradient = ($tpl_responsiveo_slider_bgmedia == 'gradient')? $params->get('tpl_responsiveo_slider_bgmedia_gradient') : '';
$tpl_responsiveo_slider_container = $params->get('tpl_responsiveo_slider_container');
$tpl_responsiveo_slider_border = $params->get('tpl_responsiveo_slider_border');
$tpl_responsiveo_slider_border_width = $params->get('tpl_responsiveo_slider_border_width');
$tpl_responsiveo_slider_border_color = $params->get('tpl_responsiveo_slider_border_color');
$tpl_responsiveo_slider_border_top_style = ($tpl_responsiveo_slider_border == 1)? $tpl_responsiveo_slider_border_width->tpl_responsiveo_border_top.'px solid '.$tpl_responsiveo_slider_border_color : 'none';
$tpl_responsiveo_slider_border_bottom_style = ($tpl_responsiveo_slider_border == 1)? $tpl_responsiveo_slider_border_width->tpl_responsiveo_border_bottom.'px solid '.$tpl_responsiveo_slider_border_color : 'none';
$tpl_responsiveo_slider_border_left_style = ($tpl_responsiveo_slider_border == 1)? $tpl_responsiveo_slider_border_width->tpl_responsiveo_border_left.'px solid '.$tpl_responsiveo_slider_border_color : 'none';
$tpl_responsiveo_slider_border_right_style = ($tpl_responsiveo_slider_border == 1)? $tpl_responsiveo_slider_border_width->tpl_responsiveo_border_right.'px solid '.$tpl_responsiveo_slider_border_color : 'none';
$tpl_responsiveo_slider_divider = $params->get('tpl_responsiveo_slider_divider');
$tpl_responsiveo_top_height = $params->get('tpl_responsiveo_top_height');
$tpl_responsiveo_top_bgcolor = $params->get('tpl_responsiveo_top_bgcolor');
$tpl_responsiveo_top_font_color = $params->get('tpl_responsiveo_top_font_color');
$tpl_responsiveo_top_container = $params->get('tpl_responsiveo_top_container');
$tpl_responsiveo_content_bgcolor = $params->get('tpl_responsiveo_content_bgcolor');
$tpl_responsiveo_content_container = $params->get('tpl_responsiveo_content_container');
$tpl_responsiveo_content_border = $params->get('tpl_responsiveo_content_border');
$tpl_responsiveo_content_border_width = $params->get('tpl_responsiveo_content_border_width');
$tpl_responsiveo_content_border_color = $params->get('tpl_responsiveo_content_border_color');
$tpl_responsiveo_content_border_top_style = ($tpl_responsiveo_content_border == 1)? $tpl_responsiveo_content_border_width->tpl_responsiveo_border_top.'px solid '.$tpl_responsiveo_content_border_color : 'none';
$tpl_responsiveo_content_border_bottom_style = ($tpl_responsiveo_content_border == 1)? $tpl_responsiveo_content_border_width->tpl_responsiveo_border_bottom.'px solid '.$tpl_responsiveo_content_border_color : 'none';
$tpl_responsiveo_content_border_left_style = ($tpl_responsiveo_content_border == 1)? $tpl_responsiveo_content_border_width->tpl_responsiveo_border_left.'px solid '.$tpl_responsiveo_content_border_color : 'none';
$tpl_responsiveo_content_border_right_style = ($tpl_responsiveo_content_border == 1)? $tpl_responsiveo_content_border_width->tpl_responsiveo_border_right.'px solid '.$tpl_responsiveo_content_border_color : 'none';
$tpl_responsiveo_content_column_count = $params->get('tpl_responsiveo_content_column_count');
$tpl_responsiveo_content_column_rule = ($tpl_responsiveo_content_column_count != 1)? $params->get('tpl_responsiveo_content_column_rule') : 'none';
$tpl_responsiveo_content_padding = $params->get('tpl_responsiveo_content_padding');
$tpl_responsiveo_bottom_height = $params->get('tpl_responsiveo_bottom_height');
$tpl_responsiveo_bottom_bgcolor = $params->get('tpl_responsiveo_bottom_bgcolor');
$tpl_responsiveo_bottom_font_color = $params->get('tpl_responsiveo_bottom_font_color');
$tpl_responsiveo_bottom_container = $params->get('tpl_responsiveo_bottom_container');
$tpl_responsiveo_footer_height = $params->get('tpl_responsiveo_footer_height');
$tpl_responsiveo_footer_bgcolor = $params->get('tpl_responsiveo_footer_bgcolor');
$tpl_responsiveo_footer_font_color = $params->get('tpl_responsiveo_footer_font_color');
$tpl_responsiveo_footer_bgmedia = $params->get('tpl_responsiveo_footer_bgmedia');
$tpl_responsiveo_footer_bgmedia_image = $params->get('tpl_responsiveo_footer_bgmedia_image');
$tpl_responsiveo_footer_bgmedia_image_repeat = $params->get('tpl_responsiveo_footer_bgmedia_image_repeat');
$tpl_responsiveo_footer_bgmedia_image_size = $params->get('tpl_responsiveo_footer_bgmedia_image_size');
$tpl_responsiveo_footer_bgimage = ($tpl_responsiveo_footer_bgmedia == 'image')? ' url('.JPATH_SITE.$tpl_responsiveo_footer_bgmedia_image.') '.$tpl_responsiveo_footer_bgmedia_image_repeat : '';
$tpl_responsiveo_footer_container = $params->get('tpl_responsiveo_footer_container');
$tpl_responsiveo_footer_border = $params->get('tpl_responsiveo_footer_border');
$tpl_responsiveo_footer_border_width = $params->get('tpl_responsiveo_footer_border_width');
$tpl_responsiveo_footer_border_color = $params->get('tpl_responsiveo_footer_border_color');
$tpl_responsiveo_footer_border_style = ($tpl_responsiveo_footer_border == 1)? $tpl_responsiveo_footer_border_width.'px solid '.$tpl_responsiveo_footer_border_color : 'none';
$tpl_responsiveo_footer_padding = $params->get('tpl_responsiveo_footer_padding');
$tpl_responsiveo_custom_css = $params->get('tpl_responsiveo_custom_css');

$navbar_toggle = array('none','block');
$navbar_collapse = array('block','none');
$navbar_collapse_in = array('none','block');

function tpl_responsiveo_article_image($articleImageSrc){
	$article = JTable::getInstance("content"); 
	$article->load(JRequest::getVar('article_id'));
	$article_images = $article->get("images"); // Get image parameters
	$images = json_decode($article_images); // Split the parameters apart
	$mod_jmg_article_img_src = ($articleImageSrc == 'image_fulltext')? $images->image_fulltext : $images->image_intro;
	return $mod_jmg_article_img_src;
}

if($tpl_responsiveo_google_fonts_load == 1){
$tpl_responsiveo_heading_font_family_block = 'h1,h2,h3,h4,h5,h6{
	font-family: '.$tpl_responsiveo_heading_font_family.';
}
';
}
?>
body{
	font-family: <?php echo $tpl_responsiveo_default_font_family;?>;
	font-size: <?php echo $tpl_responsiveo_font_size;?>px;
	color: <?php echo $tpl_responsiveo_font_color;?>;
	line-height: <?php echo $tpl_responsiveo_line_height;?>px;
	background: <?php echo $tpl_responsiveo_body_color.$tpl_responsiveo_body_bgimage;?>;
	background-size: <?php echo $tpl_responsiveo_body_bgmedia_image_size;?>;
}
<?php echo $tpl_responsiveo_heading_font_family_block;?>
h1,h2,h3,h4,h5,h6{
	color: <?php echo $tpl_responsiveo_heading_font_color;?>;
	line-height: 100%;
}
li.active a,
a:hover,
a:focus {
	color: <?php echo $tpl_responsiveo_heading_font_color;?>;
	  text-decoration: underline;
}
h1{
	font-size: <?php echo $tpl_responsiveo_h1_font_size;?>em;
}
h2{
	font-size: <?php echo $tpl_responsiveo_h2_font_size;?>em;
}
h3{
	font-size: <?php echo $tpl_responsiveo_h3_font_size;?>em;
}
h4{
	font-size: <?php echo $tpl_responsiveo_h4_font_size;?>em;
}
.responsiveo-infobar{
	background: <?php echo $tpl_responsiveo_infobar_bgcolor;?>;
}
.responsiveo-header{
	background: <?php echo $tpl_responsiveo_header_bgcolor.$tpl_responsiveo_header_bgimage;?>;
	background-size: <?php echo $tpl_responsiveo_header_bgmedia_image_size;?>;
	border-top: <?php echo $tpl_responsiveo_header_border_top_style;?>;
	border-bottom: <?php echo $tpl_responsiveo_header_border_bottom_style;?>;
	border-left: <?php echo $tpl_responsiveo_header_border_left_style;?>;
	border-right: <?php echo $tpl_responsiveo_header_border_right_style;?>;
}
.responsiveo-header-wrapper{
	padding-top: <?php echo $tpl_responsiveo_header_padding->tpl_responsiveo_padding_top;?>px;
	padding-bottom: <?php echo $tpl_responsiveo_header_padding->tpl_responsiveo_padding_bottom;?>px;
	padding-left: <?php echo $tpl_responsiveo_header_padding->tpl_responsiveo_padding_left;?>px;
	padding-right: <?php echo $tpl_responsiveo_header_padding->tpl_responsiveo_padding_right;?>px;
}
.responsiveo-slider{
	background: <?php echo $tpl_responsiveo_slider_bgcolor.$tpl_responsiveo_slider_bgimage;?>;
	background-size: <?php echo $tpl_responsiveo_slider_bgmedia_image_size;?>;
	border-top: <?php echo $tpl_responsiveo_slider_border_top_style;?>;
	border-bottom: <?php echo $tpl_responsiveo_slider_border_bottom_style;?>;
	border-left: <?php echo $tpl_responsiveo_slider_border_left_style;?>;
	border-right: <?php echo $tpl_responsiveo_slider_border_right_style;?>;
}
.responsiveo-top{
	background: <?php echo $tpl_responsiveo_top_bgcolor;?>;
	color: <?php echo $tpl_responsiveo_top_font_color;?>;
}
.responsiveo-top a,
.responsiveo-top h1,
.responsiveo-top h2,
.responsiveo-top h3,
.responsiveo-top h4{
	color: <?php echo $tpl_responsiveo_top_font_color;?>;
}
.responsiveo-content{
	background: <?php echo $tpl_responsiveo_content_bgcolor;?>;
	border-top: <?php echo $tpl_responsiveo_content_border_top_style;?>;
	border-bottom: <?php echo $tpl_responsiveo_content_border_bottom_style;?>;
	border-left: <?php echo $tpl_responsiveo_content_border_left_style;?>;
	border-right: <?php echo $tpl_responsiveo_content_border_right_style;?>;
	padding-top: <?php echo $tpl_responsiveo_content_padding->tpl_responsiveo_padding_top;?>px;
	padding-bottom: <?php echo $tpl_responsiveo_content_padding->tpl_responsiveo_padding_bottom;?>px;
	padding-left: <?php echo $tpl_responsiveo_content_padding->tpl_responsiveo_padding_left;?>px;
	padding-right: <?php echo $tpl_responsiveo_content_padding->tpl_responsiveo_padding_right;?>px;
}
.responsiveo-bottom{
	background: <?php echo $tpl_responsiveo_bottom_bgcolor;?>;
	color: <?php echo $tpl_responsiveo_bottom_font_color;?>;
}
.responsiveo-bottom a,
.responsiveo-bottom h1,
.responsiveo-bottom h2,
.responsiveo-bottom h3,
.responsiveo-bottom h4{
	color: <?php echo $tpl_responsiveo_bottom_font_color;?>;
}
.responsiveo-footer{
	background: <?php echo $tpl_responsiveo_footer_bgcolor.$tpl_responsiveo_footer_bgimage;?>;
	background-size: <?php echo $tpl_responsiveo_footer_bgmedia_image_size;?>;
	border-top: <?php echo $tpl_responsiveo_footer_border_style;?>;
	color: <?php echo $tpl_responsiveo_footer_font_color;?>;
	padding-top: <?php echo $tpl_responsiveo_footer_padding->tpl_responsiveo_padding_top;?>px;
	padding-bottom: <?php echo $tpl_responsiveo_footer_padding->tpl_responsiveo_padding_bottom;?>px;
	padding-left: <?php echo $tpl_responsiveo_footer_padding->tpl_responsiveo_padding_left;?>px;
	padding-right: <?php echo $tpl_responsiveo_footer_padding->tpl_responsiveo_padding_right;?>px;
}
.responsiveo-footer a,
.responsiveo-footer h1,
.responsiveo-footer h2,
.responsiveo-footer h3,
.responsiveo-footer h4{
	color: <?php echo $tpl_responsiveo_footer_font_color;?>;
}
nav.mainmenu ul li a{
	font-size: <?php echo $tpl_responsiveo_menu_font_size;?>em;
	padding-top: <?php echo $tpl_responsiveo_main_menu_padding->tpl_responsiveo_padding_top;?>px;
	padding-bottom: <?php echo $tpl_responsiveo_main_menu_padding->tpl_responsiveo_padding_bottom;?>px;
	padding-left: <?php echo $tpl_responsiveo_main_menu_padding->tpl_responsiveo_padding_left;?>px;
	padding-right: <?php echo $tpl_responsiveo_main_menu_padding->tpl_responsiveo_padding_right;?>px;
}
@media (max-width: 767px) {
	.container{
		width: <?php echo $tpl_responsiveo_container_width->tpl_responsiveo_container_width_mob_portrait;?>%;
	}
	.reponsiveo-header-place-holder,
	.responsiveo-header,
	.responsiveo-header-wrapper,
	.responsiveo-header-wrapper .row:first-child{
		min-height: <?php echo $tpl_responsiveo_header_height->tpl_responsiveo_height_mob_portrait;?>px;
	}
	.responsiveo-header-video-wrapper{
		height: <?php echo $tpl_responsiveo_header_height->tpl_responsiveo_height_mob_portrait;?>px;
	}
	.responsiveo-slider,
	.responsiveo-slider-wrapper{
		height: <?php echo $tpl_responsiveo_slider_height->tpl_responsiveo_height_mob_portrait;?>px;
	}
	.responsiveo-top{
		min-height: <?php echo $tpl_responsiveo_top_height->tpl_responsiveo_height_mob_portrait;?>px;
	}
	.responsiveo-bottom{
		min-height: <?php echo $tpl_responsiveo_bottom_height->tpl_responsiveo_height_mob_portrait;?>px;
	}
	.responsiveo-footer,
	.responsiveo-footer-wrapper{
		min-height: <?php echo $tpl_responsiveo_footer_height->tpl_responsiveo_height_mob_portrait;?>px;
	}
	.navbar-toggle{
		display: <?php echo $navbar_toggle[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_mob_portrait];?>!important;
	}
	.navbar-collapse.collapse {
		display: <?php echo $navbar_collapse[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_mob_portrait];?>!important;
	}
	.navbar-collapse.collapse.in {
		display: <?php echo $navbar_collapse_in[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_mob_portrait];?>!important;
	}
}
@media (min-width: 768px) and (max-width: 991px) {
	.container{
		width: <?php echo $tpl_responsiveo_container_width->tpl_responsiveo_container_width_tab_portrait;?>%;
	}
	.reponsiveo-header-place-holder,
	.responsiveo-header,
	.responsiveo-header-wrapper,
	.responsiveo-header-wrapper .row:first-child{
		min-height: <?php echo $tpl_responsiveo_header_height->tpl_responsiveo_height_tab_portrait;?>px;
	}
	.responsiveo-header-video-wrapper{
		height: <?php echo $tpl_responsiveo_header_height->tpl_responsiveo_height_tab_portrait;?>px;
	}
	.responsiveo-slider,
	.responsiveo-slider-wrapper{
		height: <?php echo $tpl_responsiveo_slider_height->tpl_responsiveo_height_tab_portrait;?>px;
	}
	.responsiveo-top{
		min-height: <?php echo $tpl_responsiveo_top_height->tpl_responsiveo_height_tab_portrait;?>px;
	}
	.responsiveo-bottom{
		min-height: <?php echo $tpl_responsiveo_bottom_height->tpl_responsiveo_height_tab_portrait;?>px;
	}
	.responsiveo-footer,
	.responsiveo-footer-wrapper{
		min-height: <?php echo $tpl_responsiveo_footer_height->tpl_responsiveo_height_tab_portrait;?>px;
	}
	.navbar-toggle{
		display: <?php echo $navbar_toggle[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_tab_portrait];?>!important;
	}
	.navbar-collapse.collapse {
		display: <?php echo $navbar_collapse[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_tab_portrait];?>!important;
	}
	.navbar-collapse.collapse.in {
		display: <?php echo $navbar_collapse_in[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_tab_portrait];?>!important;
	}
}
@media (min-width: 992px) and (max-width: 1199px) {
	.container{
		width: <?php echo $tpl_responsiveo_container_width->tpl_responsiveo_container_width_tab_landscape;?>px;
	}
	.reponsiveo-header-place-holder,
	.responsiveo-header,
	.responsiveo-header-wrapper,
	.responsiveo-header-wrapper .row:first-child{
		min-height: <?php echo $tpl_responsiveo_header_height->tpl_responsiveo_height_tab_landscape;?>px;
	}
	.responsiveo-header-video-wrapper{
		height: <?php echo $tpl_responsiveo_header_height->tpl_responsiveo_height_tab_landscape;?>px;
	}
	.responsiveo-slider,
	.responsiveo-slider-wrapper{
		height: <?php echo $tpl_responsiveo_slider_height->tpl_responsiveo_height_tab_landscape;?>px;
	}
	.responsiveo-top{
		min-height: <?php echo $tpl_responsiveo_top_height->tpl_responsiveo_height_tab_landscape;?>px;
	}
	.responsiveo-bottom{
		min-height: <?php echo $tpl_responsiveo_bottom_height->tpl_responsiveo_height_tab_landscape;?>px;
	}
	.responsiveo-footer,
	.responsiveo-footer-wrapper{
		min-height: <?php echo $tpl_responsiveo_footer_height->tpl_responsiveo_height_tab_landscape;?>px;
	}
	div[itemprop="articleBody"]{
		column-count: <?php echo $tpl_responsiveo_content_column_count;?>;
		column-rule-color: <?php echo $tpl_responsiveo_heading_font_color;?>;
		column-rule-width: 1px;
		column-rule-style: <?php echo $tpl_responsiveo_content_column_rule;?>;
	}
	.navbar-toggle{
		display: <?php echo $navbar_toggle[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_tab_landscape];?>!important;
	}
	.navbar-collapse.collapse {
		display: <?php echo $navbar_collapse[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_tab_landscape];?>!important;
	}
	.navbar-collapse.collapse.in {
		display: <?php echo $navbar_collapse_in[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_tab_landscape];?>!important;
	}
}
@media (min-width: 1200px) {
	.container{
		width: <?php echo $tpl_responsiveo_container_width->tpl_responsiveo_container_width_screen;?>px;
	}
	.reponsiveo-header-place-holder,
	.responsiveo-header,
	.responsiveo-header-wrapper{
		min-height: <?php echo $tpl_responsiveo_header_height->tpl_responsiveo_height_screen;?>px;
	}
	.responsiveo-header-video-wrapper{
			height: <?php echo $tpl_responsiveo_header_height->tpl_responsiveo_height_screen;?>px;
	}
	.responsiveo-slider,
	.responsiveo-slider-wrapper{
		height: <?php echo $tpl_responsiveo_slider_height->tpl_responsiveo_height_screen;?>px;
	}
	.responsiveo-top{
		min-height: <?php echo $tpl_responsiveo_top_height->tpl_responsiveo_height_screen;?>px;
	}
	.responsiveo-bottom{
		min-height: <?php echo $tpl_responsiveo_bottom_height->tpl_responsiveo_height_screen;?>px;
	}
	.responsiveo-footer,
	.responsiveo-footer-wrapper{
		min-height: <?php echo $tpl_responsiveo_footer_height->tpl_responsiveo_height_screen;?>px;
	}
	div[itemprop="articleBody"]{
		column-count: <?php echo $tpl_responsiveo_content_column_count;?>;
		column-rule-color: <?php echo $tpl_responsiveo_heading_font_color;?>;
		column-rule-width: 1px;
		column-rule-style: <?php echo $tpl_responsiveo_content_column_rule;?>;
	}
	.navbar-toggle{
		display: <?php echo $navbar_toggle[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_screen];?>!important;
	}
	.navbar-collapse.collapse {
		display: <?php echo $navbar_collapse[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_screen];?>!important;
	}
	.navbar-collapse.collapse.in {
		display: <?php echo $navbar_collapse_in[$tpl_responsiveo_main_menu_collapse->tpl_responsiveo_menu_collapse_screen];?>!important;
	}
}
<?php if ($tpl_responsiveo_main_menu_style == 'jmg-menustyle-1'): ?>
nav.mainmenu ul li.active a,
nav.mainmenu ul li a:hover{
	background: '.$tpl_responsiveo_menu_hover_bgcolor.';
}
<?php endif; ?>
<?php echo $tpl_responsiveo_custom_css;?>